package pt.iade.getmatch.dto;

public class SuccessResponse extends StatusResponse {
    public SuccessResponse() {
        super();
    }
}
